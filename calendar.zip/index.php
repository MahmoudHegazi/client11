<!DOCTYPE html>
<html>
<head>


<style>
.grid-container {
  display: grid;
  grid-template-columns: auto auto auto;
  background-color: #2196F3;
  padding: 10px;
}
.grid-item {
  background-color: rgba(255, 255, 255, 0.8);
  border: 1px solid rgba(0, 0, 0, 0.8);
  padding: 20px;
  font-size: 30px;
  text-align: center;
}
* {box-sizing: border-box;}
ul {list-style-type: none;}
body {font-family: Verdana, sans-serif;}
.month {
  padding: 35px 25px;
  width: 100%;
  background: #1abc9c;
  text-align: center;
}
.month ul {
  margin: 0;
  padding: 0;
}
.month ul li {
  color: white;
  font-size: 20px;
  text-transform: uppercase;
  letter-spacing: 3px;
}
.month .prev {
  float: left;
  padding-top: 10px;
}
.month .next {
  float: right;
  padding-top: 10px;
}
.weekdays {
  margin: 0;
  padding: 10px 0;
  background-color: #ddd;
}
.weekdays li {
  display: inline-block;
  width: 13.6%;
  color: #666;
  text-align: center;
}
.days {
  padding: 10px 0;
  background: #eee;
  margin: 0;
}
.days li {
  list-style-type: none;
  display: inline-block;
  width: 13.6%;
  text-align: center;
  margin-bottom: 5px;
  font-size:12px;
  color: #777;
}
.days li .active {
  padding: 5px;
  background: #1abc9c;
  color: white !important
}
/* Add media queries for smaller screens */
@media screen and (max-width:720px) {
  .weekdays li, .days li {width: 13.1%;}
}
@media screen and (max-width: 420px) {
  .weekdays li, .days li {width: 12.5%;}
  .days li .active {padding: 2px;}
}
@media screen and (max-width: 290px) {
  .weekdays li, .days li {width: 12.2%;}
}
</style>


</head>
<body>
<?php

function render_month($year,$month){
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "caldb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}else {
	$result = 'full';
}


$sql = "SELECT * FROM days WHERE year = " . $year . " AND month = " . $month;
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($row["used"]) {
        $output = '<li class="' . $row["day_class"] .' active" data-year="' . $row["year"] . 
		'" data-month="' . $row["month"] . '" data-date="' . $row["time_stamp"] . '" data-used="' .
		$row["used"] . '" data-day-name="'. $row["day_name"] .'" data-month-name="' .
		$row["month_name"]. '" data-day-short="' . $row["day_short_name"] . '" data-month-short="'. $row["month_short_name"] .'" id="day' . $row["id"] . '">'.$row["day"].'</li>';
        echo $output;
		} else {
        $output = '<li class="' . $row["day_class"] .'" data-year="' . $row["year"] . 
		'" data-month="' . $row["month"] . '" data-date="' . $row["time_stamp"] . '" data-used="' .
		$row["used"] . '" data-day-name="'. $row["day_name"] .'" data-month-name="' .
		$row["month_name"]. '" data-day-short="' . $row["day_short_name"] . '" data-month-short="'. $row["month_short_name"] .'" id="day' . $row["id"] . '">'.$row["day"].'</li>';
        echo $output;			
			
		}
    } 

    
} else {
    echo "0 results";
}

}
//SELECT `year`, count(year) AS a FROM `days` GROUP BY year
//SELECT COUNT(DISTINCT `year`) as total_years FROM `days`
//echo "$month";
//print_r($day_data[1]);
?>






<select id="years_list">
<?php 


$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "caldb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}else {
	$result = 'full';
}



$sql = "SELECT DISTINCT year as ayear FROM days";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
	$current_year = date("Y");
    while($row = $result->fetch_assoc()) {

        if ($row["ayear"] == $current_year) {
        $output = '<option class="year_option" value="'. $row["ayear"]  . '" selected>'.$row["ayear"].'</option>';
		 echo $output;
		} else {
        $output = '<option class="year_option" value="'. $row["ayear"]  . '">'.$row["ayear"].'</option>';
		 echo $output;			
		}
    } 

    
} else {
    echo "0 results";
}


?>
</select>



<?php $current_year = date("Y"); ?>


<div class="grid-container">
  <div class="grid-item">
<div>
<div class="month">      
  <ul>
    <li>
      January<br>
      <span style="font-size:18px" class="year_text"><?php echo $current_year; ?></span>
    </li>
  </ul>
</div>
<ul class="days" id="month1">  
<?php render_month($current_year,1); ?>
</ul>
</div></div>
  <div class="grid-item">
<div>
<div class="month">      
  <ul>
    <li>
      February<br>
      <span style="font-size:18px" class="year_text"><?php echo $current_year; ?></span>
    </li>
  </ul>
</div>
<ul class="days" id="month2">  

<?php render_month($current_year,2); ?>
</ul>
</div></div>
  <div class="grid-item">
<div>
<div class="month">      
  <ul>
    <li>
      March<br>
      <span style="font-size:18px" class="year_text"><?php echo $current_year; ?></span>
    </li>
  </ul>
</div>
<ul class="days" id="month3">  
<?php render_month($current_year,2); ?>
</ul>
</div></div>  
  <div class="grid-item">
<div>
<div class="month">      
  <ul>
    <li>
      April<br>
      <span style="font-size:18px" class="year_text"><?php echo $current_year; ?></span>
    </li>
  </ul>
</div>
<ul class="days" id="month4">  
<?php render_month($current_year,2); ?>
</ul>
</div></div>
  <div class="grid-item">
<div>
<div class="month">      
  <ul>
    <li>
      May<br>
      <span style="font-size:18px" class="year_text"><?php echo $current_year; ?></span>
    </li>
  </ul>
</div>
<ul class="days" id="month5">  
<?php render_month($current_year,2); ?>
</ul>
</div></div>
  <div class="grid-item">
<div>
<div class="month">      
  <ul>
    <li>
      June<br>
      <span style="font-size:18px" class="year_text"><?php echo $current_year; ?></span>
    </li>
  </ul>
</div>
<ul class="days" id="month6">  
<?php render_month($current_year,2); ?>
</ul>
</div></div>  
  <div class="grid-item">
<div>
<div class="month">      
  <ul>
    <li>
      July<br>
      <span style="font-size:18px" class="year_text"><?php echo $current_year; ?></span>
    </li>
  </ul>
</div>
<ul class="days" id="month7">  
<?php render_month($current_year,2); ?>
</ul>
</div></div>
  <div class="grid-item">
<div>
<div class="month">      
  <ul>
    <li>
      August<br>
      <span style="font-size:18px" class="year_text"><?php echo $current_year; ?></span>
    </li>
  </ul>
</div>
<ul class="days" id="month8">  
<?php render_month($current_year,2); ?>
</ul>
</div></div>
  <div class="grid-item">
<div>
<div class="month">      
  <ul>
    <li>
      September<br>
      <span style="font-size:18px" class="year_text"><?php echo $current_year; ?></span>
    </li>
  </ul>
</div>
<ul class="days" id="month9">  
<?php render_month($current_year,2); ?>
</ul>
</div></div>
  <div class="grid-item">
<div>
<div class="month">      
  <ul>
    <li>
      October<br>
      <span style="font-size:18px" class="year_text"><?php echo $current_year; ?></span>
    </li>
  </ul>
</div>
<ul class="days" id="month10">  
<?php render_month($current_year,2); ?>
</ul>
</div></div> 
  <div class="grid-item">
<div>
<div class="month">      
  <ul>
    <li>
      November<br>
      <span style="font-size:18px" class="year_text"><?php echo $current_year; ?></span>
    </li>
  </ul>
</div>
<ul class="days" id="month11">  
<?php render_month($current_year,2); ?>

</ul>
</div></div> 
  <div class="grid-item">
<div>
<div class="month">      
  <ul>
    <li>
      December<br>
	  
	  
      <span style="font-size:18px" class="year_text"><?php echo $current_year; ?></span>
    </li>
  </ul>
</div>
<ul class="days" id="month12">  
<?php render_month($current_year,2); ?>
</ul>
</div></div> 
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>


window.addEventListener('DOMContentLoaded', (event) => {
	const yearList= document.querySelector('#years_list');
    const years_text = document.querySelectorAll('.year_text');
	yearList.addEventListener('change', ()=> {
	   years_text.forEach( (year_txt) => {
		  $get_year = yearList.value;
	      year_txt.innerText = yearList.value;
		  
		  
		  
	   })
      
	});
});





$("#years_list").change(function(e){
     $.ajax({
            type: "GET",
            url: 'get_year.php?year=' + $('#years_list').find(":selected").text(),
			data: 'hello',
            success: function(data){
                      alert(data);
					  let x = document.getElementById('month1');
					  let x1 = document.getElementById('month2');
					  let x2 = document.getElementById('month3');
					  let x3 = document.getElementById('month4');
					  let x4 = document.getElementById('month5');
					  let x5 = document.getElementById('month6');
					  let x6 = document.getElementById('month7');
					  let x7 = document.getElementById('month8');
					  let x8 = document.getElementById('month9');
					  let x9 = document.getElementById('month10');
					  let x10 = document.getElementById('month11');
					  let x11 = document.getElementById('month12');
					  var res = data.split("|");
					  x.innerHTML = res[0];
					  x1.innerHTML = res[1];
					  x2.innerHTML = res[2];
					  x3.innerHTML = res[3];
					  x4.innerHTML = res[4];
					  x5.innerHTML = res[5];
					  x6.innerHTML = res[6];
					  x7.innerHTML = res[7];
					  x8.innerHTML = res[8];
					  x9.innerHTML = res[9];
					  x10.innerHTML = res[10];
					  x11.innerHTML = res[11];
					  
					  
                      
					  
            }
     });
     return false;
}); 

</script>


</body>
</html>